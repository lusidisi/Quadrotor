#include "bsp_pwmoutput.h"
#include "bsp_usart.h"
//static void PWMOUTPUT_TIM1_NVIC_Config(void)
//{
//    NVIC_InitTypeDef NVIC_InitStructure; 
//    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);		
//    NVIC_InitStructure.NVIC_IRQChannel = TIM1_CC_IRQn ;	
//    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;	 
//    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;	
//    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//    NVIC_Init(&NVIC_InitStructure);
//}
static void PWMOUTPUT_TIM1_Config(void)
{
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	TIM_OCInitTypeDef  TIM_OCInitStructure;	
	
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);	

    TIM_TimeBaseStructure.TIM_Period=2000;
    TIM_TimeBaseStructure.TIM_Prescaler= 720;	
    TIM_TimeBaseStructure.TIM_ClockDivision=TIM_CKD_DIV1;		
    TIM_TimeBaseStructure.TIM_CounterMode=TIM_CounterMode_Up; 		
		TIM_TimeBaseStructure.TIM_RepetitionCounter=0;	
    TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);

		TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;	    				
		TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;	
		TIM_OCInitStructure.TIM_Pulse = 0;	
		TIM_OCInitStructure.TIM_OCIdleState=TIM_OCIdleState_Set;
		TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
	
    TIM_ClearFlag(TIM1, TIM_FLAG_Update);//�����־λ
	  	
		TIM_OC1Init(TIM1, &TIM_OCInitStructure);	 						
		TIM_OC1PreloadConfig (TIM1, TIM_OCPreload_Enable);
		TIM_OC2Init(TIM1, &TIM_OCInitStructure);							
		TIM_OC2PreloadConfig (TIM1, TIM_OCPreload_Enable);
		TIM_OC3Init(TIM1, &TIM_OCInitStructure);	 							
		TIM_OC3PreloadConfig (TIM1, TIM_OCPreload_Enable);
		TIM_OC4Init(TIM1, &TIM_OCInitStructure);	 							
		TIM_OC4PreloadConfig (TIM1, TIM_OCPreload_Enable);//ʹ��ͨ����Ԥװ��
		TIM_CtrlPWMOutputs(TIM1, ENABLE);   //�߼���ʱ��
		TIM_ARRPreloadConfig(TIM1, ENABLE);	
    TIM_Cmd(TIM1, ENABLE);
}
void PWMOUTPUT_GPIO_Config(){
	GPIO_InitTypeDef GPIO_InitStructure;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA, ENABLE); 
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_8 ;	
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_9 ;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_10 ;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_11 ;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
}

void PWMOUTPUT_Init(){
	PWMOUTPUT_GPIO_Config();
	//PWMOUTPUT_TIM1_NVIC_Config();
	PWMOUTPUT_TIM1_Config();
}

void SetPWM1(uint32_t space){
	TIM1->CCR1 = space;
}
void SetPWM2(uint32_t space){
	TIM1->CCR2 = space;
}
void SetPWM3(uint32_t space){
	TIM1->CCR3 = space;
}
void SetPWM4(uint32_t space){
	TIM1->CCR4 = space;
}
