#include "stm32f10x.h"
#include "bsp_pwminput.h"
#include "bsp_usart.h"
#include "bsp_pwmoutput.h"
volatile uint32_t time = 0;
volatile uint8_t aRxBuffer[100]={0x00};
volatile uint8_t RxCounter=0;
volatile uint8_t ReceiveState=0;
int k = 0;
extern uint8_t pFlag;
//time 10us

/**
  * @brief  ������
  * @param  ��
  * @retval ��
  */
void delay(int i){
	while(i>0)i--;
}

int main(void)
{	
	uint8_t i = 0;
	USART_Config();
	PWMOUTPUT_Init();
	PWMINPUT_Init();
	SetPWM1(100);
	SetPWM2(200);
	SetPWM3(300);
	SetPWM4(400);
	//printf("ok1");
//	while(1){
//		for(int i = 1;i<1999;i++){
//				SetPWM1(i);
//				delay(10000);
//			}
//	}	
//	delay(1000000);
//	SetPWM1(200);
//	SetPWM2(200);
//	SetPWM3(200);
//	SetPWM4(200);


//		
//		for(int i = 1999;i>1;i--){
//			SetPWM1(i);
//			delay(10000);
//		}
//	}
	while (1)
	{
//		if(TIM_ICUserValueStructure.Capture_FinishFlag == 1)
//		{
//			time = TIM_ICUserValueStructure.Capture_Period * (2000+1) + 
//			       (TIM_ICUserValueStructure.Capture_CcrValue+1);			
//			TIM_ICUserValueStructure.Capture_FinishFlag = 0;
//			if(time>80&&time<200){
//			printf("%d\n",time);
//			}
//		}
		printf("ok2\n");
		delay(500000);
		if(pFlag>0){
			printf("%d %d %d %d\n",PWMIN_USER_BASE.PWMINPUT1,PWMIN_USER_BASE.PWMINPUT2,PWMIN_USER_BASE.PWMINPUT3,PWMIN_USER_BASE.PWMINPUT4);
			switch(pFlag){
				case 1:{
					printf("pwm1:%d\n",PWMIN_USER_BASE.PWMINPUT1);
					pFlag=0;
					//SetPWM1(i);
					delay(10000);
					break;
				}
				case 2:{
					printf("pwm2:%d\n",PWMIN_USER_BASE.PWMINPUT2);
					pFlag=0;
					//SetPWM2(i);
					delay(10000);
					break;
				}
				case 3:{
					printf("pwm3:%d\n",PWMIN_USER_BASE.PWMINPUT3);
					pFlag=0;
					//SetPWM3(i);
					delay(10000);
					break;
				}
				case 4:{
					printf("pwm4:%d\n",PWMIN_USER_BASE.PWMINPUT4);
					pFlag=0;
					//SetPWM4(i);
					delay(10000);
					break;
				}
			}
			SetPWM1(PWMIN_USER_BASE.PWMINPUT1);
			SetPWM2(PWMIN_USER_BASE.PWMINPUT2);
			SetPWM3(PWMIN_USER_BASE.PWMINPUT3);
			SetPWM4(PWMIN_USER_BASE.PWMINPUT4);
		}
		if(ReceiveState==1){
			ReceiveState=0;
			i=0;
			while(RxCounter--){
				Usart_SendByte(USART1,aRxBuffer[i++]);
				while(USART_GetFlagStatus(USART1,USART_FLAG_TC)==RESET);
			}
			RxCounter=0;
		}
	}	
}



/*********************************************END OF FILE**********************/

