#ifndef __STM32F10x_PWMOUTPUT_H
#define __STM32F10x_PWMOUTPUT_H

#include "stm32f10x.h"
void PWMOUTPUT_Init(void);
void SetPWM1(uint32_t space);
void SetPWM2(uint32_t space);
void SetPWM3(uint32_t space);
void SetPWM4(uint32_t space);
#endif


