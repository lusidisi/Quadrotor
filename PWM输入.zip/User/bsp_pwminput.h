#ifndef __STM32F10x_PWMINPUT_H
#define __STM32F10x_PWMINPUT_H

#include "stm32f10x.h"

typedef struct
{   
	uint8_t   Capture_FinishFlag;  
	uint8_t   Capture_StartFlag;  
	uint16_t  Capture_CcrValue;
	uint16_t  Capture_Period;
}TIM_ICUserValueTypeDef;
typedef struct{
	uint16_t PWMINPUT1;
	uint16_t PWMINPUT2;
	uint16_t PWMINPUT3;
	uint16_t PWMINPUT4;
}PWMIN_BASE;//��������pwmÿһ·���񵽵�CCRX��ֵ

extern TIM_ICUserValueTypeDef TIM_ICUserValueStructure;
extern PWMIN_BASE PWMIN_USER_BASE;
void PWMINPUT_Init(void);

#endif
