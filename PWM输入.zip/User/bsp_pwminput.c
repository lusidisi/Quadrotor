
#include "bsp_pwminput.h"

TIM_ICUserValueTypeDef TIM_ICUserValueStructure = {0,0,0,0};
PWMIN_BASE PWMIN_USER_BASE = {0,0,0,0};
static void PWMINPUT_TIM2_NVIC_Config(void)
{
    NVIC_InitTypeDef NVIC_InitStructure; 
    // �����ж���Ϊ0
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_0);		
		// �����ж���Դ
    NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;	
		// ���������ȼ�Ϊ 0
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;	 
	  // ������ռ���ȼ�Ϊ3
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 3;	
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
    NVIC_Init(&NVIC_InitStructure);
}

static void PWMINPUT_TIM2_Config(void){
	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);//ʱ�ӿ���
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_0;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;  
  GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_1;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_2;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	GPIO_InitStructure.GPIO_Pin =  GPIO_Pin_3;//pwm��������GPIO��ʼ��
	GPIO_Init(GPIOA, &GPIO_InitStructure);
		
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2,ENABLE);
	TIM_TimeBaseStructure.TIM_Period=(2000-1);	
	TIM_TimeBaseStructure.TIM_Prescaler=(720-1);	//72M/720=0.1MHZ 100us��ʱһ�Σ�2000�Σ���20ms����һ���ж�
	TIM_TimeBaseStructure.TIM_ClockDivision=TIM_CKD_DIV1;		
	TIM_TimeBaseStructure.TIM_CounterMode=TIM_CounterMode_Up;		
	TIM_TimeBaseStructure.TIM_RepetitionCounter=0;	
	TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);
	
	TIM_ICInitTypeDef  TIM_ICInitStructure;
  TIM_ICInitStructure.TIM_Channel = TIM_Channel_1;
  TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;
  TIM_ICInitStructure.TIM_ICSelection = TIM_ICSelection_DirectTI;
  TIM_ICInitStructure.TIM_ICPrescaler = TIM_ICPSC_DIV1;
  TIM_ICInitStructure.TIM_ICFilter = 0x0;
  TIM_ICInit(TIM2, &TIM_ICInitStructure);	
	TIM_ICInitStructure.TIM_Channel = TIM_Channel_2;
	TIM_ICInit(TIM2, &TIM_ICInitStructure);
	TIM_ICInitStructure.TIM_Channel = TIM_Channel_3;
	TIM_ICInit(TIM2, &TIM_ICInitStructure);
	TIM_ICInitStructure.TIM_Channel = TIM_Channel_4;
	TIM_ICInit(TIM2, &TIM_ICInitStructure);
	
	TIM_ClearITPendingBit(TIM2, TIM_IT_CC1);
	TIM_ITConfig (TIM2,TIM_IT_CC1, ENABLE );
	TIM_ClearITPendingBit(TIM2, TIM_IT_CC2);
	TIM_ITConfig (TIM2,TIM_IT_CC2, ENABLE );
	TIM_ClearITPendingBit(TIM2, TIM_IT_CC3);
	TIM_ITConfig (TIM2,TIM_IT_CC3, ENABLE );
	TIM_ClearITPendingBit(TIM2, TIM_IT_CC4);
	TIM_ITConfig (TIM2,TIM_IT_CC4, ENABLE );
	//TIM_ITConfig (TIM2, TIM_IT_Update, ENABLE );
  TIM_Cmd(TIM2, ENABLE);
}

void PWMINPUT_Init(void){
	PWMINPUT_TIM2_NVIC_Config();
	PWMINPUT_TIM2_Config();
}



