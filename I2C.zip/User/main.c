#include "stm32f10x.h"  
#include "stm32f10x_it.h"
#include "delay.h"
#include "bsp_usart.h"
#include "GY86_I2C.h"
#include "mpu6050.h"
#include "ESP8266.h"
#define TASK_ENABLE 0

extern unsigned int Task_Delay[2];

void delay(int a){
	while(a>0)a--;
}
void SysTick_Init(void)
{
	/* SystemFrequency / 1000    1ms�ж�һ��
	 * SystemFrequency / 100000	 10us�ж�һ��
	 * SystemFrequency / 1000000 1us�ж�һ��
	 */
//	if (SysTick_Config(SystemFrequency / 100000))	// ST3.0.0��汾
	if (SysTick_Config(SystemCoreClock/1000))	// ST3.5.0��汾SystemCoreClock/10���ܳ���16777216
	{ 
		/* Capture error */ 
		while (1);
	}
		// �رյδ�ʱ��  
	SysTick->CTRL &= ~ SysTick_CTRL_ENABLE_Msk;
}
int main(void)
{
	short Acel[3];
	short Gyro[3];
	float Temp;
	int counter=0;
	DelayInit();
	USART_Config();
	printf("Init finish\n");
	GY86_I2C_Configuration();
	SysTick_Init();
	SysTick->CTRL|=SysTick_CTRL_ENABLE_Msk;
	MPU6050_Init();
//	while(1){
//		if(Task_Delay[0]==TASK_ENABLE)
//			{
//				Task_Delay[0]=1000;
//			}
//		if(Task_Delay[1]==0){
//			printf("this is data from stm32 %d\n",counter++);
//			Task_Delay[1]=500;
//		}
//	}
//	if(ReceiveState==1){
//			ReceiveState=0;
//			buffercounter=0;
//			while(RxCounter--){
//				Usart_SendByte(USART1,aRxBuffer[buffercounter++]);
//				while(USART_GetFlagStatus(USART1,USART_FLAG_TC)==RESET);
//			}
//			RxCounter=0;
//	}
	if (MPU6050ReadID() == 1)
	{	
		while(1)
		{
			if(Task_Delay[0]==TASK_ENABLE)
			{
				Task_Delay[0]=1000;
			}
			if(Task_Delay[1]==0)
			{
				MPU6050ReadAcc(Acel);
				printf("���ٶȣ�%8d%8d%8d",Acel[0],Acel[1],Acel[2]);
				MPU6050ReadGyro(Gyro);
				printf("    ������%8d%8d%8d",Gyro[0],Gyro[1],Gyro[2]);
				MPU6050_ReturnTemp(&Temp);
				printf("    �¶�%8.2f\r\n",Temp);
				
				Task_Delay[1]=500;//����һ�����ݣ��ɸ����Լ���������߲���Ƶ�ʣ���100ms����һ��
			}

			//*************************************	��������������ĸ�ʽ************************************//
	//		if(Task_Delay[i]==0)
	//		{
	//			Task(i);
	//			Task_Delay[i]=;
	//		}

		}

	}
	else
	{
		printf("\r\nû�м�⵽MPU6050��������\r\n");
	
		while(1);	
	}
}


