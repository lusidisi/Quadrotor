#include "ESP8266.h"
#include "bsp_usart.h"
void esp8266Init(){
	printf("AT+RST\r\n");
}
