#include "GY86_I2C.h"
#include "delay.h"
#include "mpu6050.h"

#define I2Cx_OWN_ADDRESS7      0X30
#define I2C_Speed              400000 

static __IO uint32_t  I2CTimeout = I2CT_LONG_TIMEOUT; 
static uint8_t I2C_TIMEOUT_UserCallback(void);

void GY86_I2C_Configuration(void)
{
	I2C_InitTypeDef  I2C_InitStructure;
	GPIO_InitTypeDef  GPIO_InitStructure; 

	SENSORS_I2C_APBxClock_FUN(RCC_APB1Periph_I2C1,ENABLE);
	SENSORS_I2C_GPIO_APBxClock_FUN (SENSORS_I2C_GPIO_CLK|SENSORS_I2C_REMAP_CLK,ENABLE);//��ӳ��ʱ��ҲҪ��

	/*STM32F103C8T6оƬ��Ӳ��I2C: PB8 -- SCL; PB9 -- SDA */
	GPIO_PinRemapConfig(GPIO_Remap_I2C1, ENABLE);	//��ӳ��I2C
	GPIO_InitStructure.GPIO_Pin =  SENSORS_I2C_SCL_PIN | SENSORS_I2C_SDA_PIN ;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_OD;//I2C���뿪©���
	GPIO_Init(GPIOB, &GPIO_InitStructure);

	I2C_DeInit(SENSORS_I2Cx );//ʹ��I2C1
	I2C_InitStructure.I2C_Mode = I2C_Mode_I2C;
	I2C_InitStructure.I2C_DutyCycle = I2C_DutyCycle_2;
	I2C_InitStructure.I2C_OwnAddress1 = I2Cx_OWN_ADDRESS7;//������I2C��ַ,���д��
	I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;
	I2C_InitStructure.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
	I2C_InitStructure.I2C_ClockSpeed = I2C_Speed;//400K

	I2C_Cmd(SENSORS_I2Cx , ENABLE);
	I2C_Init(SENSORS_I2Cx , &I2C_InitStructure);
}

uint8_t I2C_ByteWrite(u8 pBuffer, u8 WriteAddr)
{
  I2C_GenerateSTART(SENSORS_I2Cx, ENABLE);//������ʼλ
	I2CTimeout = I2CT_FLAG_TIMEOUT;
  while(!I2C_CheckEvent(SENSORS_I2Cx, I2C_EVENT_MASTER_MODE_SELECT))
  {
    if((I2CTimeout--) == 0) return I2C_TIMEOUT_UserCallback();
  } 
	
  I2C_Send7bitAddress(SENSORS_I2Cx, MPU6050_SLAVE_ADDRESS, I2C_Direction_Transmitter);//��������ַ��д�ź�
  I2CTimeout = I2CT_FLAG_TIMEOUT;
  while(!I2C_CheckEvent(SENSORS_I2Cx, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED)) 
	{
    if((I2CTimeout--) == 0) return I2C_TIMEOUT_UserCallback();
  } 
      
  I2C_SendData(SENSORS_I2Cx, WriteAddr);//�Ĵ�����ַ
	I2CTimeout = I2CT_FLAG_TIMEOUT;
  while(!I2C_CheckEvent(SENSORS_I2Cx, I2C_EVENT_MASTER_BYTE_TRANSMITTED))
	{
    if((I2CTimeout--) == 0) return I2C_TIMEOUT_UserCallback();
  } 

  I2C_SendData(SENSORS_I2Cx, pBuffer); //д������
	I2CTimeout = I2CT_FLAG_TIMEOUT;  
  while(!I2C_CheckEvent(SENSORS_I2Cx, I2C_EVENT_MASTER_BYTE_TRANSMITTED))	
	{
    if((I2CTimeout--) == 0) return I2C_TIMEOUT_UserCallback();
  } 
  I2C_GenerateSTOP(SENSORS_I2Cx, ENABLE);
	
	return 1; //��������1
}

uint8_t I2C_BufferRead(u8* pBuffer, u8 ReadAddr, u16 NumByteToRead)
{  
  I2CTimeout = I2CT_LONG_TIMEOUT;
  while(I2C_GetFlagStatus(SENSORS_I2Cx, I2C_FLAG_BUSY))    
  {
    if((I2CTimeout--) == 0) return I2C_TIMEOUT_UserCallback();
  }
  
	I2C_GenerateSTART(SENSORS_I2Cx, ENABLE);//������ʼλ
	I2CTimeout = I2CT_FLAG_TIMEOUT;
  while(!I2C_CheckEvent(SENSORS_I2Cx, I2C_EVENT_MASTER_MODE_SELECT))
	{
    if((I2CTimeout--) == 0) return I2C_TIMEOUT_UserCallback();
  }
	
  I2C_Send7bitAddress(SENSORS_I2Cx, MPU6050_SLAVE_ADDRESS, I2C_Direction_Transmitter);
	I2CTimeout = I2CT_FLAG_TIMEOUT;
  while(!I2C_CheckEvent(SENSORS_I2Cx, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED)) 
	{
    if((I2CTimeout--) == 0) return I2C_TIMEOUT_UserCallback();
  }//���ʹ�������ַ��д�ź�
	
  I2C_Cmd(SENSORS_I2Cx, ENABLE);//��������PEλ�����EV6�¼���
	
	I2C_SendData(SENSORS_I2Cx, ReadAddr);//���ͼĴ�����ַ 
	I2CTimeout = I2CT_FLAG_TIMEOUT;
  while(!I2C_CheckEvent(SENSORS_I2Cx, I2C_EVENT_MASTER_BYTE_TRANSMITTED))
	{
    if((I2CTimeout--) == 0) return I2C_TIMEOUT_UserCallback();
  }
	
  I2C_GenerateSTART(SENSORS_I2Cx, ENABLE);//�ڶ��η���ʼ�ź�
	I2CTimeout = I2CT_FLAG_TIMEOUT;
  while(!I2C_CheckEvent(SENSORS_I2Cx, I2C_EVENT_MASTER_MODE_SELECT))
	{
    if((I2CTimeout--) == 0) return I2C_TIMEOUT_UserCallback();
  }
		
	I2C_Send7bitAddress(SENSORS_I2Cx, MPU6050_SLAVE_ADDRESS, I2C_Direction_Receiver);//���ʹ�������ַ�����ź�
	I2CTimeout = I2CT_FLAG_TIMEOUT;
  while(!I2C_CheckEvent(SENSORS_I2Cx, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED))
	{
    if((I2CTimeout--) == 0) return I2C_TIMEOUT_UserCallback();
  }
  
  while(NumByteToRead)  
  {
    if(NumByteToRead == 1)//�������һ�����ݣ���������
    {  
      I2C_AcknowledgeConfig(SENSORS_I2Cx, DISABLE); 
      I2C_GenerateSTOP(SENSORS_I2Cx, ENABLE);
    }
    if(I2C_CheckEvent(SENSORS_I2Cx, I2C_EVENT_MASTER_BYTE_RECEIVED))//�������������
    {      
      *pBuffer = I2C_ReceiveData(SENSORS_I2Cx);
      pBuffer++; 
      NumByteToRead--;        
    }   
  }

  I2C_AcknowledgeConfig(SENSORS_I2Cx, ENABLE);//׼����һ�δ���
	
	return 1; //����������1
}


void I2C_WaitStandbyState(void)      
{
  vu16 SR1_Tmp = 0;

  do
  {
    /* Send START condition */
    I2C_GenerateSTART(SENSORS_I2Cx, ENABLE);
    /* Read I2C1 SR1 register */
    SR1_Tmp = I2C_ReadRegister(SENSORS_I2Cx, I2C_Register_SR1);
    /* Send slave address for write */
    I2C_Send7bitAddress(SENSORS_I2Cx, MPU6050_SLAVE_ADDRESS, I2C_Direction_Transmitter);
  }while(!(I2C_ReadRegister(SENSORS_I2Cx, I2C_Register_SR1) & 0x0002));
  
  /* Clear AF flag */
  I2C_ClearFlag(SENSORS_I2Cx, I2C_FLAG_AF);
    /* STOP condition */    
    I2C_GenerateSTOP(SENSORS_I2Cx, ENABLE); 
}


static uint8_t I2C_TIMEOUT_UserCallback(void)
{
  /* Block communication and all processes */
  MPU_ERROR("I2C Timeout error!"); 
  
  return 0;
}

